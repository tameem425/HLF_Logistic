import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shipment-detail',
  templateUrl: './shipment-detail.component.html',
  styleUrls: ['./shipment-detail.component.css']
})
export class ShipmentDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
