import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shipment-main',
  templateUrl: './shipment-main.component.html',
  styleUrls: ['./shipment-main.component.css']
})
export class ShipmentMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
